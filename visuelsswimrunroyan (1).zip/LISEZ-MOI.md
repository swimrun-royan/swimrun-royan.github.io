# Visuels de secours — swimrun-royan.com

Sept fichiers remplacent les images actuellement cassees (elles pointent vers
l'ancien domaine swimrun-royan.fr, hors service).

## Ou les mettre

Creer un dossier `images/` a la racine du site et y deposer les 7 fichiers.

## Remplacements a faire dans le code

Remplacer les URL absolues `https://swimrun-royan.fr/...` par des chemins locaux :

| Ancienne URL (a supprimer)                                                   | Nouveau chemin                  |
|------------------------------------------------------------------------------|---------------------------------|
| .../themes/Webpack/asset/src/img/svg/logo.svg                                 | images/logo.png                 |
| .../uploads/2024/02/S.png                                                     | images/S.png                    |
| .../uploads/2024/02/M.png                                                     | images/M.png                    |
| .../uploads/2024/02/L.png                                                     | images/L.png                    |
| .../uploads/2024/03/swiper_1.png                                              | images/swiper_1.png             |
| .../uploads/2024/03/swiper_2.png                                              | images/swiper_2.png             |
| .../uploads/2024/02/background_accueil-e1709113065883.png                     | images/background_accueil.png   |

Attention : la derniere n'est pas dans une balise `<img>`, elle est appelee en CSS
dans la regle `.hero` :

```css
.hero {
  background: linear-gradient(rgba(19,42,76,.55), rgba(19,42,76,.55)),
              url("images/background_accueil.png") center/cover no-repeat;
}
```

Le logo passe de .svg a .png : penser a corriger l'extension dans la balise `<img>`
du header (`alt="Logo SwimRun Royan"`).

## Verification

Une fois en ligne, ouvrir la page et verifier qu'aucune requete vers
swimrun-royan.fr ne subsiste (onglet Reseau des outils de developpement).
Faire le meme controle sur les autres pages du site.

## Statut des visuels

- S.png / M.png / L.png : definitifs, aux couleurs du site (#132a4c / #e5127d).
- logo.png : PROVISOIRE. A remplacer par le vrai logo (lezard rose) des qu'il
  est retrouve. Fichier transparent, prevu pour un fond blanc.
- swiper_1.png : VRAIE PHOTO de l'epreuve (saut depuis le rocher), recadree au
  format du bloc et debarrassee du texte promotionnel. Source basse definition
  (447 px) : correcte a l'affichage standard, un peu douce sur ecran retina.
  Une version .jpg (176 Ko au lieu de 1,2 Mo) est fournie a cote : la preferer.
- background_accueil.png / swiper_2.png : PROVISOIRES.
  A remplacer par de vraies photos de l'epreuve.
